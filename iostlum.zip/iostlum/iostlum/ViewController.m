//
//  ViewController.m
//  iostlum
//
//  Created by student on 20/11/2023.
//  Copyright © 2023 student. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [_informationButton setTitle:NSLocalizedString(@"Information", nil) forState:UIControlStateNormal];
    [_wipl setImage:[UIImage imageNamed:NSLocalizedString(@"image", nil)]];
}

- (IBAction)Information {
    NSString *facultyString = NSLocalizedString(@"krotszy", nil);
    
    UIAlertController *alertDialog = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Information", nil)
                                                                         message:[NSString stringWithFormat:facultyString, 4]
                                                                  preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *defaultAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil)
                                                            style:UIAlertActionStyleDefault
                                                          handler:^(UIAlertAction *action){}];
    [alertDialog addAction:defaultAction];
    [self presentViewController:alertDialog animated:YES completion:nil];
}

@end
