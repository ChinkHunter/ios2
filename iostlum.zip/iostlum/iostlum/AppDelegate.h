//
//  AppDelegate.h
//  iostlum
//
//  Created by student on 20/11/2023.
//  Copyright © 2023 student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

