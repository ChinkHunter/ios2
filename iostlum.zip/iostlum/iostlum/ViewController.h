//
//  ViewController.h
//  iostlum
//
//  Created by student on 20/11/2023.
//  Copyright © 2023 student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (nonatomic, weak) IBOutlet UIButton *informationButton;
-(IBAction)Information;

@property (nonatomic, weak) IBOutlet UIImageView *wipl;
@end
